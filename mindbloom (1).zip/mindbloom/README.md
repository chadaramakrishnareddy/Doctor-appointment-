# 🌱 MindBloom — Gen Z Mental Health App

A complete, production-ready mental health platform UI with dark glassmorphism aesthetic.

## 🚀 Getting Started

Simply open `index.html` in any modern browser. No build step, no dependencies to install.

---

## 🔐 Demo Credentials

| Role    | Email                     | Password  |
|---------|---------------------------|-----------|
| Patient | patient@mindbloom.com     | pass123   |
| Admin   | admin@mindbloom.com       | admin123  |

---

## 📄 Pages Included

| Page | Description |
|------|-------------|
| **Login** | Sign-in with demo credential buttons + feature highlights panel |
| **Register** | New account creation with onboarding questions |
| **Patient Dashboard** | Mood check-in, next appointment, quick actions, resources |
| **Doctor Listing** | 6 specialist cards with search, filter by specialty, and detail modal |
| **Book Appointment** | Doctor summary, date/time picker, slot selection, session type |
| **Patient Details Form** | Full health profile: personal info, emergency contact, mental health history, medical info, preferences |
| **Admin Dashboard** | Sidebar navigation with 5 sections: Overview, Patients table, Doctors grid, Analytics with progress bars, Settings |

---

## 🎨 Design System

- **Aesthetic**: Dark glassmorphism with animated mesh blobs and noise texture
- **Fonts**: Syne (headings) + DM Sans (body) — Google Fonts
- **Colors**: Deep dark `#0a0a0f` background, lime green `#c8f556` primary, purple/pink/blue accents
- **Components**: Cards, badges, chips, avatars, stat cards, sidebar, modals, toasts
- **Motion**: Blob float animations, fade-in stagger, modal pop-in

---

## 📁 File Structure

```
mindbloom/
├── index.html          # All pages (SPA routing)
├── css/
│   └── styles.css      # Complete design system
├── js/
│   └── app.js          # App state, routing, render functions
└── README.md
```

---

## 💡 Features

- ✅ SPA routing (no page reloads)
- ✅ 6 specialist doctor profiles with specialties, bios, ratings, fees
- ✅ Doctor search & filter by specialty tag
- ✅ Doctor detail modal
- ✅ Appointment booking with time slot selection
- ✅ Full patient intake form
- ✅ Admin dashboard with patients table, doctors grid, analytics, settings
- ✅ Toast notifications
- ✅ Mood check-in widget
- ✅ Responsive design
- ✅ Glassmorphism UI with animated backgrounds
