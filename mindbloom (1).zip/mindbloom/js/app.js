// ── APP STATE ──
const App = {
  currentUser: null,
  currentRole: null, // 'patient' | 'admin'
  selectedDoctor: null,
  bookingDoctor: null,

  // Demo credentials
  users: [
    { id: 1, email: 'patient@mindbloom.com', password: 'pass123', role: 'patient', name: 'Alex Rivera', age: 23, joined: '2024-01' },
    { id: 2, email: 'admin@mindbloom.com',   password: 'admin123', role: 'admin',   name: 'Admin Morgan', age: 30, joined: '2023-06' }
  ],

  doctors: [
    {
      id: 1,
      name: 'Dr. Priya Sharma',
      specialty: 'Anxiety & Stress',
      subSpec: 'Cognitive Behavioral Therapy',
      rating: 4.9,
      reviews: 312,
      experience: '8 yrs',
      fee: 1500,
      available: true,
      avatar: 'PS',
      avatarClass: 'avatar-lime',
      tags: ['CBT', 'Mindfulness', 'OCD'],
      bio: 'Specializes in helping young adults navigate anxiety, burnout, and the pressures of modern life through evidence-based CBT and mindfulness techniques.',
      slots: ['9:00 AM', '11:00 AM', '2:00 PM', '4:00 PM'],
      badge: 'badge-lime',
      icon: '🧠'
    },
    {
      id: 2,
      name: 'Dr. Arjun Menon',
      specialty: 'Depression & Mood',
      subSpec: 'Psychodynamic Therapy',
      rating: 4.8,
      reviews: 248,
      experience: '10 yrs',
      fee: 1800,
      available: true,
      avatar: 'AM',
      avatarClass: 'avatar-purple',
      tags: ['Depression', 'Grief', 'Relationships'],
      bio: 'Expert in mood disorders and emotional wellness, helping patients build resilience and rediscover joy through psychodynamic and integrative therapy.',
      slots: ['10:00 AM', '1:00 PM', '3:30 PM', '5:00 PM'],
      badge: 'badge-purple',
      icon: '💜'
    },
    {
      id: 3,
      name: 'Dr. Zara Osei',
      specialty: 'Trauma & PTSD',
      subSpec: 'EMDR Therapy',
      rating: 4.95,
      reviews: 189,
      experience: '12 yrs',
      fee: 2000,
      available: true,
      avatar: 'ZO',
      avatarClass: 'avatar-pink',
      tags: ['EMDR', 'PTSD', 'Trauma', 'ACE'],
      bio: 'Trauma-informed specialist using EMDR and somatic therapies to help individuals process difficult experiences and reclaim their narrative.',
      slots: ['8:30 AM', '12:00 PM', '3:00 PM', '6:00 PM'],
      badge: 'badge-pink',
      icon: '🌸'
    },
    {
      id: 4,
      name: 'Dr. Kai Nakamura',
      specialty: 'ADHD & Neurodiversity',
      subSpec: 'Behavioral Coaching',
      rating: 4.85,
      reviews: 276,
      experience: '7 yrs',
      fee: 1600,
      available: false,
      avatar: 'KN',
      avatarClass: 'avatar-blue',
      tags: ['ADHD', 'Autism', 'Executive Function'],
      bio: 'Neurodiversity advocate and specialist helping ADHD and autistic individuals build systems, strategies, and self-acceptance for thriving daily lives.',
      slots: [],
      badge: 'badge-blue',
      icon: '⚡'
    },
    {
      id: 5,
      name: 'Dr. Leila Hassan',
      specialty: 'Relationships & Identity',
      subSpec: 'ACT & Narrative Therapy',
      rating: 4.87,
      reviews: 203,
      experience: '9 yrs',
      fee: 1700,
      available: true,
      avatar: 'LH',
      avatarClass: 'avatar-lime',
      tags: ['LGBTQ+', 'Identity', 'Couples', 'ACT'],
      bio: 'Passionate about helping people explore identity, navigate relationships, and live authentically. LGBTQ+ affirming and culturally sensitive practice.',
      slots: ['9:30 AM', '11:30 AM', '2:30 PM', '5:30 PM'],
      badge: 'badge-lime',
      icon: '🌈'
    },
    {
      id: 6,
      name: 'Dr. Marcus Bell',
      specialty: 'Addiction & Recovery',
      subSpec: 'Motivational Interviewing',
      rating: 4.78,
      reviews: 156,
      experience: '15 yrs',
      fee: 1900,
      available: true,
      avatar: 'MB',
      avatarClass: 'avatar-purple',
      tags: ['Addiction', 'Recovery', 'Substance Use'],
      bio: 'With 15 years in addiction medicine, Dr. Bell guides individuals through recovery using compassionate, non-judgmental motivational interviewing.',
      slots: ['10:30 AM', '1:30 PM', '4:30 PM'],
      badge: 'badge-purple',
      icon: '🔄'
    }
  ],

  appointments: [
    { id: 1, patientName: 'Alex Rivera', doctorName: 'Dr. Priya Sharma', date: '2025-07-15', time: '9:00 AM', type: 'Video', status: 'Confirmed', fee: 1500 },
    { id: 2, patientName: 'Sam Torres',   doctorName: 'Dr. Arjun Menon',   date: '2025-07-16', time: '1:00 PM', type: 'Chat',  status: 'Pending',   fee: 1800 },
    { id: 3, patientName: 'Jordan Kim',   doctorName: 'Dr. Zara Osei',     date: '2025-07-17', time: '3:00 PM', type: 'Video', status: 'Confirmed', fee: 2000 },
    { id: 4, patientName: 'Maya Patel',   doctorName: 'Dr. Leila Hassan',  date: '2025-07-14', time: '2:30 PM', type: 'Audio', status: 'Completed', fee: 1700 },
  ],

  patients: [
    { id: 1, name: 'Alex Rivera',  age: 23, email: 'alex@mail.com',  condition: 'Anxiety',    doctor: 'Dr. Priya Sharma',  status: 'Active',    joined: 'Jan 2025' },
    { id: 2, name: 'Sam Torres',   age: 27, email: 'sam@mail.com',   condition: 'Depression', doctor: 'Dr. Arjun Menon',   status: 'Active',    joined: 'Feb 2025' },
    { id: 3, name: 'Jordan Kim',   age: 19, email: 'jkim@mail.com',  condition: 'PTSD',       doctor: 'Dr. Zara Osei',     status: 'Active',    joined: 'Mar 2025' },
    { id: 4, name: 'Maya Patel',   age: 25, email: 'maya@mail.com',  condition: 'ADHD',       doctor: 'Dr. Kai Nakamura',  status: 'Inactive',  joined: 'Dec 2024' },
    { id: 5, name: 'Chris Lane',   age: 31, email: 'chris@mail.com', condition: 'Addiction',  doctor: 'Dr. Marcus Bell',   status: 'Active',    joined: 'Apr 2025' },
  ]
};

// ── ROUTER ──
function navigate(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById(pageId);
  if (target) {
    target.classList.add('active');
    window.scrollTo(0, 0);
  }
}

// ── AUTH ──
function login() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value.trim();
  const err      = document.getElementById('login-error');

  const user = App.users.find(u => u.email === email && u.password === password);
  if (!user) {
    err.textContent = 'Wrong email or password. Try patient@mindbloom.com / pass123';
    err.style.display = 'block';
    return;
  }
  err.style.display = 'none';
  App.currentUser = user;
  App.currentRole = user.role;

  if (user.role === 'admin') {
    renderAdmin();
    navigate('page-admin');
  } else {
    renderDashboard();
    navigate('page-dashboard');
  }
  showToast(`Welcome back, ${user.name.split(' ')[0]}! 👋`, 'success');
}

function logout() {
  App.currentUser = null;
  App.currentRole = null;
  navigate('page-login');
  showToast('Logged out successfully.', 'success');
}

// ── TOAST ──
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || '✅'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

// ── RENDER DOCTORS ──
function renderDoctors(filter = 'all') {
  const grid = document.getElementById('doctors-grid');
  if (!grid) return;
  const filtered = filter === 'all' ? App.doctors : App.doctors.filter(d => d.specialty.toLowerCase().includes(filter.toLowerCase()) || d.tags.some(t => t.toLowerCase().includes(filter.toLowerCase())));

  grid.innerHTML = filtered.map(doc => `
    <div class="card doctor-card fade-in" style="padding:28px; cursor:pointer;" onclick="openDoctorModal(${doc.id})">
      <div style="display:flex; align-items:flex-start; gap:16px; margin-bottom:20px;">
        <div class="avatar avatar-lg ${doc.avatarClass}">${doc.avatar}</div>
        <div style="flex:1;">
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
            <h3 style="font-size:17px;">${doc.name}</h3>
            ${doc.available ? '<span class="badge badge-green" style="font-size:11px;">● Available</span>' : '<span class="badge" style="font-size:11px;background:rgba(255,255,255,0.05);color:var(--text-muted);">● Busy</span>'}
          </div>
          <div style="font-size:14px; color:var(--accent); font-weight:600;">${doc.specialty}</div>
          <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">${doc.subSpec}</div>
        </div>
        <div style="font-size:28px;">${doc.icon}</div>
      </div>
      <p style="font-size:13px; color:var(--text-muted); line-height:1.6; margin-bottom:16px;">${doc.bio.substring(0,120)}...</p>
      <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:16px;">
        ${doc.tags.map(t => `<span class="tag">${t}</span>`).join('')}
      </div>
      <div class="divider" style="margin:16px 0;"></div>
      <div style="display:flex; align-items:center; justify-content:space-between;">
        <div style="display:flex; gap:16px; font-size:13px; color:var(--text-muted);">
          <span>⭐ ${doc.rating} (${doc.reviews})</span>
          <span>🕐 ${doc.experience}</span>
        </div>
        <div style="font-family:'Syne',sans-serif; font-weight:700; color:var(--primary);">₹${doc.fee.toLocaleString()}</div>
      </div>
      <button class="btn btn-primary btn-full btn-sm" style="margin-top:16px;" onclick="event.stopPropagation(); bookDoctor(${doc.id})">
        Book Session
      </button>
    </div>
  `).join('');
}

// ── DOCTOR MODAL ──
function openDoctorModal(id) {
  const doc = App.doctors.find(d => d.id === id);
  if (!doc) return;
  document.getElementById('modal-content').innerHTML = `
    <div style="display:flex; align-items:center; gap:20px; margin-bottom:24px;">
      <div class="avatar avatar-lg ${doc.avatarClass}">${doc.avatar}</div>
      <div>
        <h2 style="font-size:24px; margin-bottom:4px;">${doc.name}</h2>
        <div style="color:var(--accent); font-weight:600;">${doc.specialty}</div>
        <div style="font-size:13px; color:var(--text-muted);">${doc.subSpec}</div>
      </div>
    </div>
    <p style="color:var(--text-muted); line-height:1.7; margin-bottom:20px;">${doc.bio}</p>
    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:20px;">
      <div class="card" style="padding:16px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:var(--primary); font-family:'Syne',sans-serif;">${doc.rating}</div>
        <div style="font-size:12px; color:var(--text-muted);">Rating</div>
      </div>
      <div class="card" style="padding:16px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:var(--accent); font-family:'Syne',sans-serif;">${doc.reviews}</div>
        <div style="font-size:12px; color:var(--text-muted);">Reviews</div>
      </div>
      <div class="card" style="padding:16px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:var(--accent2); font-family:'Syne',sans-serif;">${doc.experience}</div>
        <div style="font-size:12px; color:var(--text-muted);">Experience</div>
      </div>
    </div>
    <div style="display:flex; gap:12px;">
      <button class="btn btn-ghost" style="flex:1;" onclick="closeModal()">Close</button>
      ${doc.available ? `<button class="btn btn-primary" style="flex:1;" onclick="closeModal(); bookDoctor(${doc.id})">Book Now — ₹${doc.fee.toLocaleString()}</button>` : `<button class="btn btn-ghost" style="flex:1;" disabled>Not Available</button>`}
    </div>
  `;
  document.getElementById('doctor-modal').classList.add('open');
}

function closeModal() {
  document.getElementById('doctor-modal').classList.remove('open');
}

// ── BOOK DOCTOR ──
function bookDoctor(id) {
  App.bookingDoctor = App.doctors.find(d => d.id === id);
  if (!App.bookingDoctor) return;

  // Pre-fill booking form
  document.getElementById('booking-doctor-name').textContent = App.bookingDoctor.name;
  document.getElementById('booking-specialty').textContent = App.bookingDoctor.specialty;
  document.getElementById('booking-fee').textContent = `₹${App.bookingDoctor.fee.toLocaleString()}`;

  const slotsEl = document.getElementById('booking-slots');
  if (App.bookingDoctor.slots.length) {
    slotsEl.innerHTML = App.bookingDoctor.slots.map(s => `<div class="chip" onclick="selectSlot(this, '${s}')">${s}</div>`).join('');
  } else {
    slotsEl.innerHTML = '<p style="color:var(--text-muted);font-size:13px;">No slots available currently.</p>';
  }

  navigate('page-book');
}

function selectSlot(el, time) {
  document.querySelectorAll('#booking-slots .chip').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
}

function submitBooking() {
  const date    = document.getElementById('book-date').value;
  const type    = document.getElementById('book-type').value;
  const concern = document.getElementById('book-concern').value;

  if (!date || !type || !concern) {
    showToast('Please fill all fields!', 'error');
    return;
  }
  const selectedSlot = document.querySelector('#booking-slots .chip.selected');
  if (!selectedSlot && App.bookingDoctor.slots.length) {
    showToast('Please select a time slot!', 'error');
    return;
  }

  showToast('Appointment booked successfully! 🎉', 'success');
  navigate('page-dashboard');
  renderDashboard();
}

// ── RENDER DASHBOARD ──
function renderDashboard() {
  const u = App.currentUser;
  if (!u) return;
  document.getElementById('dash-name').textContent = u.name.split(' ')[0];

  const nextAppt = App.appointments.find(a => a.patientName === u.name);
  const el = document.getElementById('dash-next-appt');
  if (nextAppt) {
    el.innerHTML = `
      <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px;">
        <div>
          <div style="font-size:13px; color:var(--text-muted); margin-bottom:4px;">Next Session</div>
          <div style="font-size:18px; font-weight:700; font-family:'Syne',sans-serif;">${nextAppt.doctorName}</div>
          <div style="font-size:14px; color:var(--text-muted);">${nextAppt.date} · ${nextAppt.time} · ${nextAppt.type}</div>
        </div>
        <span class="badge badge-green">✓ Confirmed</span>
      </div>
    `;
  } else {
    el.innerHTML = `<div style="color:var(--text-muted); font-size:14px;">No upcoming appointments. <span style="color:var(--primary); cursor:pointer;" onclick="navigate('page-doctors')">Book one →</span></div>`;
  }
}

// ── PATIENT FORM ──
function submitPatientForm() {
  const fields = ['pf-name','pf-dob','pf-gender','pf-phone','pf-email','pf-emergency','pf-condition','pf-medications'];
  const empty = fields.filter(id => !document.getElementById(id).value);
  if (empty.length) {
    showToast('Please fill all required fields.', 'error');
    return;
  }
  showToast('Patient profile saved successfully! ✅', 'success');
  navigate('page-dashboard');
}

// ── ADMIN ──
function renderAdmin() {
  renderAdminSection('dashboard');
}

function renderAdminSection(section) {
  // Update sidebar active
  document.querySelectorAll('.sidebar-item').forEach(el => el.classList.remove('active'));
  document.querySelector(`[data-section="${section}"]`)?.classList.add('active');

  const content = document.getElementById('admin-main');
  if (!content) return;

  if (section === 'dashboard') {
    content.innerHTML = `
      <div class="stagger">
        <div style="margin-bottom:32px;">
          <h1 class="section-title" style="font-size:32px;">Admin <span class="highlight">Dashboard</span></h1>
          <p style="color:var(--text-muted); margin-top:8px;">Platform overview for MindBloom ✦</p>
        </div>
        <div class="grid-4" style="margin-bottom:32px;">
          <div class="stat-card lime">
            <div class="stat-icon">👥</div>
            <div class="stat-value" style="color:var(--primary);">${App.patients.length}</div>
            <div class="stat-label">Total Patients</div>
          </div>
          <div class="stat-card purple">
            <div class="stat-icon">🩺</div>
            <div class="stat-value" style="color:var(--accent);">${App.doctors.length}</div>
            <div class="stat-label">Doctors</div>
          </div>
          <div class="stat-card pink">
            <div class="stat-icon">📅</div>
            <div class="stat-value" style="color:var(--accent2);">${App.appointments.length}</div>
            <div class="stat-label">Appointments</div>
          </div>
          <div class="stat-card blue">
            <div class="stat-icon">💰</div>
            <div class="stat-value" style="color:var(--accent3); font-size:30px;">₹${(App.appointments.reduce((s,a)=>s+a.fee,0)/1000).toFixed(0)}K</div>
            <div class="stat-label">Revenue</div>
          </div>
        </div>
        <div class="card" style="padding:28px;">
          <h3 style="margin-bottom:20px;">Recent Appointments</h3>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Type</th><th>Status</th><th>Fee</th></tr></thead>
              <tbody>
                ${App.appointments.map(a => `
                  <tr>
                    <td style="color:var(--text); font-weight:500;">${a.patientName}</td>
                    <td>${a.doctorName}</td>
                    <td>${a.date}</td>
                    <td>${a.time}</td>
                    <td><span class="tag">${a.type}</span></td>
                    <td><span class="badge ${a.status==='Confirmed'?'badge-green':a.status==='Pending'?'badge-blue':'badge-purple'}">${a.status}</span></td>
                    <td style="color:var(--primary); font-weight:600;">₹${a.fee.toLocaleString()}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  } else if (section === 'patients') {
    content.innerHTML = `
      <div class="stagger">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:32px; flex-wrap:wrap; gap:12px;">
          <h1 class="section-title" style="font-size:32px;">Patient <span class="highlight">Records</span></h1>
          <button class="btn btn-primary btn-sm" onclick="showToast('Feature coming soon!','info')">+ Add Patient</button>
        </div>
        <div class="card" style="padding:28px;">
          <div class="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Age</th><th>Email</th><th>Condition</th><th>Doctor</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead>
              <tbody>
                ${App.patients.map(p => `
                  <tr>
                    <td style="color:var(--text); font-weight:600;">${p.name}</td>
                    <td>${p.age}</td>
                    <td style="color:var(--text-muted);">${p.email}</td>
                    <td><span class="tag">${p.condition}</span></td>
                    <td style="font-size:13px;">${p.doctor}</td>
                    <td><span class="badge ${p.status==='Active'?'badge-green':'badge-purple'}">${p.status}</span></td>
                    <td style="color:var(--text-muted); font-size:13px;">${p.joined}</td>
                    <td><button class="btn btn-ghost btn-sm" onclick="showToast('Viewing ${p.name}','info')">View</button></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  } else if (section === 'doctors') {
    content.innerHTML = `
      <div class="stagger">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:32px; flex-wrap:wrap; gap:12px;">
          <h1 class="section-title" style="font-size:32px;">Doctor <span class="highlight">Management</span></h1>
          <button class="btn btn-primary btn-sm" onclick="showToast('Feature coming soon!','info')">+ Add Doctor</button>
        </div>
        <div class="grid-3">
          ${App.doctors.map(doc => `
            <div class="card" style="padding:24px;">
              <div style="display:flex; align-items:center; gap:14px; margin-bottom:16px;">
                <div class="avatar ${doc.avatarClass}">${doc.avatar}</div>
                <div>
                  <div style="font-weight:700; font-family:'Syne',sans-serif; font-size:15px;">${doc.name}</div>
                  <div style="font-size:12px; color:var(--accent);">${doc.specialty}</div>
                </div>
              </div>
              <div style="display:flex; justify-content:space-between; font-size:13px; color:var(--text-muted); margin-bottom:14px;">
                <span>⭐ ${doc.rating}</span>
                <span>${doc.experience}</span>
                <span>₹${doc.fee.toLocaleString()}</span>
              </div>
              <div style="display:flex; gap:8px;">
                <span class="badge ${doc.available ? 'badge-green' : 'badge-purple'}">${doc.available ? 'Available' : 'Unavailable'}</span>
                <button class="btn btn-ghost btn-sm" style="margin-left:auto;" onclick="showToast('Editing ${doc.name}','info')">Edit</button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  } else if (section === 'analytics') {
    content.innerHTML = `
      <div class="stagger">
        <div style="margin-bottom:32px;">
          <h1 class="section-title" style="font-size:32px;">Platform <span class="highlight">Analytics</span></h1>
        </div>
        <div class="grid-2" style="margin-bottom:24px;">
          <div class="card" style="padding:28px;">
            <h3 style="margin-bottom:20px;">Specialty Distribution</h3>
            ${[['Anxiety & Stress','65%',0],['Depression & Mood','55%',1],['Trauma & PTSD','42%',2],['ADHD & Neurodiversity','38%',3]].map(([label,pct,i])=>`
              <div style="margin-bottom:16px;">
                <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
                  <span style="color:var(--text-muted);">${label}</span>
                  <span style="font-weight:600; color:var(--text);">${pct}</span>
                </div>
                <div class="progress-bar"><div class="progress-fill" style="width:${pct}; background:${['var(--primary)','var(--accent)','var(--accent2)','var(--accent3)'][i]};"></div></div>
              </div>
            `).join('')}
          </div>
          <div class="card" style="padding:28px;">
            <h3 style="margin-bottom:20px;">Key Metrics</h3>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
              ${[['Avg Session Rating','4.87 ⭐'],['Sessions This Month','127'],['Repeat Patients','68%'],['Avg Booking Time','4.2 min'],['Patient Satisfaction','92%'],['Active Doctors','5/6']].map(([label,val])=>`
                <div class="card" style="padding:16px;">
                  <div style="font-size:20px; font-weight:800; font-family:'Syne',sans-serif; color:var(--primary); margin-bottom:4px;">${val}</div>
                  <div style="font-size:12px; color:var(--text-muted);">${label}</div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  } else if (section === 'settings') {
    content.innerHTML = `
      <div class="stagger">
        <div style="margin-bottom:32px;">
          <h1 class="section-title" style="font-size:32px;">Platform <span class="highlight">Settings</span></h1>
        </div>
        <div class="card" style="padding:32px; max-width:600px;">
          <h3 style="margin-bottom:24px;">General Settings</h3>
          <div style="display:flex; flex-direction:column; gap:20px;">
            <div class="input-group"><label>Platform Name</label><input type="text" value="MindBloom"></div>
            <div class="input-group"><label>Support Email</label><input type="email" value="support@mindbloom.com"></div>
            <div class="input-group"><label>Default Currency</label><select><option>INR (₹)</option><option>USD ($)</option></select></div>
            <div class="input-group"><label>Session Duration (min)</label><input type="number" value="50"></div>
            <div style="display:flex; gap:12px; flex-wrap:wrap;">
              <button class="btn btn-primary" onclick="showToast('Settings saved!','success')">Save Changes</button>
              <button class="btn btn-ghost" onclick="showToast('Changes discarded.','info')">Discard</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
}

// ── DOCTOR FILTER ──
function filterDoctors() {
  const q = document.getElementById('doctor-search')?.value.toLowerCase() || '';
  const filtered = q
    ? App.doctors.filter(d => d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q) || d.tags.some(t => t.toLowerCase().includes(q)))
    : App.doctors;
  const grid = document.getElementById('doctors-grid');
  if (!grid) return;
  grid.innerHTML = filtered.map(doc => `
    <div class="card doctor-card fade-in" style="padding:28px; cursor:pointer;" onclick="openDoctorModal(${doc.id})">
      <div style="display:flex; align-items:flex-start; gap:16px; margin-bottom:20px;">
        <div class="avatar avatar-lg ${doc.avatarClass}">${doc.avatar}</div>
        <div style="flex:1;">
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
            <h3 style="font-size:17px;">${doc.name}</h3>
            ${doc.available ? '<span class="badge badge-green" style="font-size:11px;">● Available</span>' : '<span class="badge" style="font-size:11px;background:rgba(255,255,255,0.05);color:var(--text-muted);">● Busy</span>'}
          </div>
          <div style="font-size:14px; color:var(--accent); font-weight:600;">${doc.specialty}</div>
          <div style="font-size:12px; color:var(--text-muted); margin-top:2px;">${doc.subSpec}</div>
        </div>
        <div style="font-size:28px;">${doc.icon}</div>
      </div>
      <p style="font-size:13px; color:var(--text-muted); line-height:1.6; margin-bottom:16px;">${doc.bio.substring(0,120)}...</p>
      <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:16px;">
        ${doc.tags.map(t => `<span class="tag">${t}</span>`).join('')}
      </div>
      <div class="divider" style="margin:16px 0;"></div>
      <div style="display:flex; align-items:center; justify-content:space-between;">
        <div style="display:flex; gap:16px; font-size:13px; color:var(--text-muted);">
          <span>⭐ ${doc.rating} (${doc.reviews})</span>
          <span>🕐 ${doc.experience}</span>
        </div>
        <div style="font-family:'Syne',sans-serif; font-weight:700; color:var(--primary);">₹${doc.fee.toLocaleString()}</div>
      </div>
      <button class="btn btn-primary btn-full btn-sm" style="margin-top:16px;" onclick="event.stopPropagation(); bookDoctor(${doc.id})">
        Book Session
      </button>
    </div>
  `).join('') || '<p style="color:var(--text-muted); grid-column:1/-1; text-align:center; padding:40px;">No doctors found.</p>';
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
  navigate('page-login');
});
